# 🌙 LUNARA - Komplette Einrichtung

## Status deiner Installation:
- ✅ Worker deployed: `lunara-platform.n-zimmermann711.workers.dev`
- ✅ D1 Database: `DB` binding konfiguriert  
- ✅ KV Namespace: `SESSIONS` binding konfiguriert
- ✅ Stripe Account: Test-Modus aktiv

---

## 📋 CHECKLISTE (Folge jeden Schritt!)

### SCHRITT 1: Stripe Public Key (MUSS ZUERST!)
1. Öffne: https://dashboard.stripe.com/test/apikeys
2. Kopiere den **"Publishable Key"** (beginnt mit `pk_test_51SvJkv1EJs71ssaB...`)
3. Öffne `public/checkout.html`
4. Ersetze in **Zeile 212** den kompletten Key:
   ```javascript
   STRIPE_PUBLIC_KEY: 'pk_test_51SvJkv1EJs71ssaBDEIN_ECHTER_KEY_HIER',
   ```

### SCHRITT 2: Secrets in Cloudflare setzen
Führe diese Befehle im Projektordner aus:

```bash
# 1. Stripe Secret Key (von https://dashboard.stripe.com/test/apikeys)
# Kopiere den "Secret Key" (beginnt mit sk_test_)
wrangler secret put STRIPE_SECRET_KEY
# Eingabe: sk_test_51SvJkv1EJs71ssaB...

# 2. JWT Secret (beliebiger langer String für Sicherheit)
wrangler secret put JWT_SECRET
# Eingabe: lunara-super-secret-jwt-key-2024-mindestens-32-zeichen

# 3. Stripe Webhook Secret (ERST NACH SCHRITT 4!)
```

### SCHRITT 3: Datenbank initialisieren
```bash
# Datenbank-Schema erstellen
wrangler d1 execute lunara-db --remote --file=./schema.sql
```

### SCHRITT 4: Stripe Webhook einrichten
1. Öffne: https://dashboard.stripe.com/test/webhooks
2. Klicke **"Add endpoint"**
3. Endpoint URL eingeben:
   ```
   https://lunara-platform.n-zimmermann711.workers.dev/api/webhooks/stripe
   ```
4. Bei "Events to send" klicke **"+ Select events"**
5. Wähle: `checkout.session.completed`
6. Klicke **"Add endpoint"**
7. Klicke auf den neuen Webhook → **"Reveal"** bei Signing Secret
8. Kopiere den Signing Secret (beginnt mit `whsec_`)

### SCHRITT 5: Webhook Secret speichern
```bash
wrangler secret put STRIPE_WEBHOOK_SECRET
# Eingabe: whsec_xxxxxxxxxxxxx (den Key von Schritt 4)
```

### SCHRITT 6: Deployen
```bash
wrangler deploy
```

---

## 🧪 TESTEN

### Test 1: Homepage
Öffne: https://lunara-platform.n-zimmermann711.workers.dev/
→ Sollte die LUNARA Homepage mit Animation zeigen

### Test 2: Registrierung
1. Klicke auf "Konto" oder öffne /account.html
2. Klicke "Registrieren"
3. E-Mail und Passwort eingeben
→ Sollte "Willkommen! +50 Punkte" anzeigen

### Test 3: Shop & Warenkorb
1. Gehe zu /shop.html
2. Klicke auf ein Produkt → "In den Warenkorb"
3. Klicke auf Warenkorb-Icon
→ Sollte Produkt im Drawer zeigen

### Test 4: Checkout
1. Mit Produkt im Warenkorb → "Zur Kasse"
2. Bei /checkout.html → "Jetzt bezahlen"
3. Stripe Checkout öffnet sich
4. Test-Karte verwenden:
   - Nummer: `4242 4242 4242 4242`
   - Datum: Beliebig in der Zukunft
   - CVC: 123
5. "Bezahlen" klicken
→ Sollte zur Erfolgsseite weiterleiten

### Test 5: Bestellung prüfen
1. Gehe zu /account.html → "Bestellungen"
→ Sollte die Bestellung anzeigen

---

## ❌ HÄUFIGE FEHLER

### "Checkout fehlgeschlagen"
→ STRIPE_SECRET_KEY nicht gesetzt oder falsch
```bash
wrangler secret put STRIPE_SECRET_KEY
```

### "Stripe Key invalid"
→ Falscher Public Key in checkout.html
→ Stelle sicher, dass du den PUBLISHABLE Key (pk_test_...) verwendest

### "Database error"
→ Schema nicht initialisiert
```bash
wrangler d1 execute lunara-db --remote --file=./schema.sql
```

### Webhook liefert keine Bestellaktualisierung
→ STRIPE_WEBHOOK_SECRET nicht gesetzt oder falsch
→ Webhook-URL überprüfen (muss exakt stimmen)

---

## 📞 STRIPE TEST-KARTEN

| Szenario | Kartennummer | Ergebnis |
|----------|--------------|----------|
| Erfolg | 4242 4242 4242 4242 | Zahlung erfolgreich |
| Ablehnung | 4000 0000 0000 0002 | Karte abgelehnt |
| 3D Secure | 4000 0027 6000 3184 | 3D Secure Prüfung |

---

**Bei Problemen:** Console-Logs prüfen mit `wrangler tail`
