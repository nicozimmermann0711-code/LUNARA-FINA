/**
 * ═══════════════════════════════════════════════════════════════════════════
 * LUNARA – Frontend Application
 * Complete E-Commerce Frontend with Auth, Cart, Points, and Animations
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ============================================================================
// CONFIGURATION
// ============================================================================

const CONFIG = {
  API_URL: '/api',
  STRIPE_PUBLIC_KEY: 'pk_test_YOUR_STRIPE_PUBLIC_KEY', // Replace with your Stripe key
  INTRO_DURATION: 2500,
  TOAST_DURATION: 4000,
};

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

const state = {
  user: null,
  token: null,
  cart: [],
  products: [],
  wishlist: [],
  isLoading: false,
};

// Load persisted state
function loadState() {
  try {
    state.token = localStorage.getItem('lunara_token');
    state.cart = JSON.parse(localStorage.getItem('lunara_cart') || '[]');
    state.wishlist = JSON.parse(localStorage.getItem('lunara_wishlist') || '[]');
    
    // Validate and fetch user if token exists
    if (state.token) {
      fetchUser();
    }
  } catch (e) {
    console.error('Error loading state:', e);
  }
}

function saveCart() {
  localStorage.setItem('lunara_cart', JSON.stringify(state.cart));
  updateCartUI();
}

function saveWishlist() {
  localStorage.setItem('lunara_wishlist', JSON.stringify(state.wishlist));
}

// ============================================================================
// API HELPERS
// ============================================================================

async function api(endpoint, options = {}) {
  const url = `${CONFIG.API_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  
  if (state.token) {
    headers['Authorization'] = `Bearer ${state.token}`;
  }
  
  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Ein Fehler ist aufgetreten');
    }
    
    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// ============================================================================
// AUTH MODULE
// ============================================================================

async function fetchUser() {
  try {
    const data = await api('/auth/me');
    state.user = data.user;
    updateAuthUI();
  } catch (error) {
    // Token invalid, clear it
    state.token = null;
    state.user = null;
    localStorage.removeItem('lunara_token');
    updateAuthUI();
  }
}

async function login(email, password) {
  try {
    const data = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    state.token = data.token;
    state.user = data.user;
    localStorage.setItem('lunara_token', data.token);
    
    showToast('Willkommen zurück!', 'success');
    closeAuthModal();
    updateAuthUI();
    
    return data;
  } catch (error) {
    showToast(error.message, 'error');
    throw error;
  }
}

async function register(email, password, name) {
  try {
    const data = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    });
    
    state.token = data.token;
    state.user = data.user;
    localStorage.setItem('lunara_token', data.token);
    
    showToast(data.message || 'Registrierung erfolgreich!', 'success');
    closeAuthModal();
    updateAuthUI();
    
    return data;
  } catch (error) {
    showToast(error.message, 'error');
    throw error;
  }
}

async function logout() {
  try {
    await api('/auth/logout', { method: 'POST' });
  } catch (e) {
    // Ignore logout errors
  }
  
  state.token = null;
  state.user = null;
  localStorage.removeItem('lunara_token');
  
  showToast('Erfolgreich abgemeldet', 'success');
  updateAuthUI();
}

function updateAuthUI() {
  const loginBtn = document.getElementById('login-btn');
  const accountLink = document.getElementById('account-link');
  
  if (state.user) {
    loginBtn?.classList.add('hidden');
    accountLink?.classList.remove('hidden');
    
    // Update login button to show user name
    if (loginBtn) {
      loginBtn.textContent = state.user.name || state.user.email.split('@')[0];
      loginBtn.onclick = () => window.location.href = '/account.html';
    }
  } else {
    loginBtn?.classList.remove('hidden');
    accountLink?.classList.add('hidden');
    
    if (loginBtn) {
      loginBtn.textContent = 'Login';
      loginBtn.onclick = openAuthModal;
    }
  }
}

// ============================================================================
// CART MODULE
// ============================================================================

function addToCart(productId, variant, quantity = 1) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  
  const existingIndex = state.cart.findIndex(
    item => item.productId === productId && 
            item.variant.size === variant.size && 
            item.variant.color === variant.color
  );
  
  if (existingIndex > -1) {
    state.cart[existingIndex].quantity += quantity;
  } else {
    state.cart.push({
      productId,
      variant,
      quantity,
      price: product.price,
      name: product.name,
      image: product.images[0],
    });
  }
  
  saveCart();
  showToast(`${product.name} wurde zum Warenkorb hinzugefügt`, 'success');
  openCart();
}

function removeFromCart(index) {
  state.cart.splice(index, 1);
  saveCart();
}

function updateCartQuantity(index, quantity) {
  if (quantity <= 0) {
    removeFromCart(index);
  } else {
    state.cart[index].quantity = quantity;
    saveCart();
  }
}

function getCartTotal() {
  return state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
}

function getCartCount() {
  return state.cart.reduce((sum, item) => sum + item.quantity, 0);
}

function updateCartUI() {
  const countEl = document.getElementById('cart-count');
  const contentEl = document.getElementById('cart-content');
  const totalEl = document.getElementById('cart-total');
  
  if (countEl) {
    countEl.textContent = getCartCount();
  }
  
  if (contentEl) {
    if (state.cart.length === 0) {
      contentEl.innerHTML = `
        <div class="cart-empty">
          <div class="cart-empty-icon">🛒</div>
          <p>Dein Warenkorb ist leer</p>
        </div>
      `;
    } else {
      contentEl.innerHTML = state.cart.map((item, index) => `
        <div class="cart-item">
          <img src="${item.image}" alt="${item.name}">
          <div class="cart-item-details">
            <div class="cart-item-name">${item.name}</div>
            <div class="cart-item-variant">${item.variant.size} / ${item.variant.color}</div>
            <div class="cart-item-price">€${(item.price * item.quantity).toFixed(2)}</div>
          </div>
          <div class="cart-item-controls">
            <button class="quantity-btn" onclick="updateCartQuantity(${index}, ${item.quantity - 1})">−</button>
            <span>${item.quantity}</span>
            <button class="quantity-btn" onclick="updateCartQuantity(${index}, ${item.quantity + 1})">+</button>
            <button class="remove-item" onclick="removeFromCart(${index})">×</button>
          </div>
        </div>
      `).join('');
    }
  }
  
  if (totalEl) {
    totalEl.textContent = `€${getCartTotal().toFixed(2)}`;
  }
}

function openCart() {
  document.getElementById('cart-overlay')?.classList.add('active');
  document.getElementById('cart-drawer')?.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cart-overlay')?.classList.remove('active');
  document.getElementById('cart-drawer')?.classList.remove('active');
  document.body.style.overflow = '';
}

// ============================================================================
// WISHLIST MODULE
// ============================================================================

function toggleWishlist(productId) {
  const index = state.wishlist.indexOf(productId);
  
  if (index > -1) {
    state.wishlist.splice(index, 1);
    showToast('Von Wunschliste entfernt', 'success');
  } else {
    state.wishlist.push(productId);
    showToast('Zur Wunschliste hinzugefügt', 'success');
  }
  
  saveWishlist();
  updateWishlistUI();
}

function isInWishlist(productId) {
  return state.wishlist.includes(productId);
}

function updateWishlistUI() {
  document.querySelectorAll('.wishlist-btn').forEach(btn => {
    const id = parseInt(btn.dataset.id);
    if (isInWishlist(id)) {
      btn.classList.add('active');
      btn.textContent = '❤️';
    } else {
      btn.classList.remove('active');
      btn.textContent = '🤍';
    }
  });
}

// ============================================================================
// PRODUCTS MODULE
// ============================================================================

async function loadProducts() {
  try {
    const response = await fetch('/data/products.json');
    state.products = await response.json();
    return state.products;
  } catch (error) {
    console.error('Error loading products:', error);
    showToast('Produkte konnten nicht geladen werden', 'error');
    return [];
  }
}

function renderProducts(container, filter = 'All', limit = null) {
  if (!container) return;
  
  let products = state.products;
  
  if (filter && filter !== 'All') {
    products = products.filter(p => p.category.toLowerCase() === filter.toLowerCase());
  }
  
  if (limit) {
    products = products.slice(0, limit);
  }
  
  container.innerHTML = products.map(product => {
    const badge = product.tags?.[0] ? `<div class="badge">${product.tags[0]}</div>` : '';
    const wishlistActive = isInWishlist(product.id);
    
    return `
      <div class="product-card reveal">
        ${badge}
        <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
        <div class="product-info">
          <div class="product-name">${product.name}</div>
          <div class="product-price">€${product.price.toFixed(2)}</div>
          <div class="product-actions">
            <button class="btn add-cart-btn" data-id="${product.id}">In den Warenkorb</button>
            <button class="btn-secondary quick-view-btn" data-id="${product.id}">Details</button>
            <button class="btn-secondary wishlist-btn ${wishlistActive ? 'active' : ''}" data-id="${product.id}">
              ${wishlistActive ? '❤️' : '🤍'}
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
  
  // Observe new elements for reveal animation
  initRevealObserver();
}

function openQuickView(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  
  const modal = document.getElementById('product-modal');
  const content = document.getElementById('product-modal-content');
  
  const variantOptions = product.variants.map((v, i) => 
    `<option value="${i}">${v.size.toUpperCase()} / ${v.color}</option>`
  ).join('');
  
  // Quality score bars
  const qualityLabels = {
    zustand: 'Zustand',
    duft: 'Duft',
    waschzustand: 'Waschzustand',
    materialqualitaet: 'Materialqualität',
    tragedauer: 'Tragedauer',
    extras: 'Extras'
  };
  
  let qualityHtml = '';
  if (product.qualityScore) {
    qualityHtml = `
      <div class="quality-list">
        ${Object.entries(product.qualityScore).map(([key, score]) => `
          <div class="quality-item">
            <div class="quality-label">${qualityLabels[key] || key}</div>
            <div class="quality-bar">
              <div class="quality-bar-fill" data-score="${score}" style="width: ${score * 20}%"></div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }
  
  content.innerHTML = `
    <div class="modal-header">
      <h2 class="modal-title">${product.name}</h2>
      <button class="modal-close" onclick="closeQuickView()">×</button>
    </div>
    <img src="${product.images[0]}" alt="${product.name}" style="width: 100%; height: 300px; object-fit: cover; border-radius: var(--radius-md); margin-bottom: var(--space-4);">
    <p>${product.longDesc}</p>
    <p class="text-accent" style="font-size: var(--text-xl); font-weight: 600; margin: var(--space-4) 0;">
      €${product.price.toFixed(2)}
    </p>
    ${qualityHtml}
    <div class="form-group" style="margin-top: var(--space-4);">
      <label>Variante wählen</label>
      <select id="quick-view-variant">${variantOptions}</select>
    </div>
    <button class="btn" style="width: 100%; margin-top: var(--space-4);" onclick="addFromQuickView(${product.id})">
      In den Warenkorb
    </button>
  `;
  
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeQuickView() {
  document.getElementById('product-modal')?.classList.remove('active');
  document.body.style.overflow = '';
}

function addFromQuickView(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  
  const select = document.getElementById('quick-view-variant');
  const variantIndex = parseInt(select.value);
  const variant = product.variants[variantIndex];
  
  addToCart(productId, variant);
  closeQuickView();
}

// ============================================================================
// TOAST NOTIFICATIONS
// ============================================================================

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  
  container.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)';
    setTimeout(() => toast.remove(), 300);
  }, CONFIG.TOAST_DURATION);
}

// ============================================================================
// MODALS
// ============================================================================

function openAuthModal(mode = 'login') {
  const modal = document.getElementById('auth-modal');
  const title = document.getElementById('auth-modal-title');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  
  if (mode === 'register') {
    title.textContent = 'Registrieren';
    loginForm.classList.add('hidden');
    registerForm.classList.remove('hidden');
  } else {
    title.textContent = 'Login';
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
  }
  
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeAuthModal() {
  document.getElementById('auth-modal')?.classList.remove('active');
  document.body.style.overflow = '';
}

// ============================================================================
// INTRO ANIMATION
// ============================================================================

function initIntroAnimation() {
  const intro = document.getElementById('intro-overlay');
  const skipBtn = document.getElementById('intro-skip');
  const particles = document.getElementById('intro-particles');
  
  if (!intro) return;
  
  // Check if already seen in this session
  if (sessionStorage.getItem('lunara_intro_seen')) {
    intro.classList.add('hidden');
    return;
  }
  
  // Create particles
  for (let i = 0; i < 30; i++) {
    const particle = document.createElement('div');
    particle.className = 'intro-particle';
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.animationDelay = `${Math.random() * 2}s`;
    particle.style.animationDuration = `${2 + Math.random() * 2}s`;
    particles?.appendChild(particle);
  }
  
  // Skip button
  skipBtn?.addEventListener('click', () => {
    hideIntro();
  });
  
  // Auto-hide after duration
  setTimeout(hideIntro, CONFIG.INTRO_DURATION);
  
  function hideIntro() {
    intro.classList.add('hidden');
    sessionStorage.setItem('lunara_intro_seen', 'true');
  }
}

// ============================================================================
// SCROLL REVEAL ANIMATIONS
// ============================================================================

let revealObserver;

function initRevealObserver() {
  if (revealObserver) {
    revealObserver.disconnect();
  }
  
  // Check for reduced motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('revealed'));
    document.querySelectorAll('.reveal-stagger').forEach(el => el.classList.add('revealed'));
    return;
  }
  
  revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
  
  document.querySelectorAll('.reveal, .reveal-stagger').forEach(el => {
    revealObserver.observe(el);
  });
}

// ============================================================================
// HERO PARTICLES
// ============================================================================

function initHeroParticles() {
  const container = document.getElementById('hero-particles');
  if (!container) return;
  
  // Check for reduced motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return;
  }
  
  for (let i = 0; i < 20; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.animationDelay = `${Math.random() * 8}s`;
    particle.style.animationDuration = `${6 + Math.random() * 4}s`;
    particle.style.opacity = `${0.2 + Math.random() * 0.3}`;
    container.appendChild(particle);
  }
}

// ============================================================================
// NAVIGATION
// ============================================================================

function initNavigation() {
  const nav = document.getElementById('navbar');
  const toggle = document.getElementById('nav-toggle');
  const menu = document.getElementById('nav-menu');
  
  // Scroll effect
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      nav?.classList.add('scrolled');
    } else {
      nav?.classList.remove('scrolled');
    }
  });
  
  // Mobile toggle
  toggle?.addEventListener('click', () => {
    toggle.classList.toggle('active');
    menu?.classList.toggle('open');
  });
  
  // Close mobile menu on link click
  menu?.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      toggle?.classList.remove('active');
      menu?.classList.remove('open');
    });
  });
}

// ============================================================================
// SAFE EXIT
// ============================================================================

function initSafeExit() {
  const btn = document.getElementById('safe-exit-btn');
  
  btn?.addEventListener('click', () => {
    document.body.classList.toggle('safe-mode');
    
    if (document.body.classList.contains('safe-mode')) {
      btn.textContent = '🔓';
    } else {
      btn.textContent = '🔒';
    }
  });
  
  // Keyboard shortcut: Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !document.body.classList.contains('safe-mode')) {
      // Only activate if no modals are open
      const activeModals = document.querySelectorAll('.modal-overlay.active');
      if (activeModals.length === 0) {
        document.body.classList.add('safe-mode');
        btn.textContent = '🔓';
      }
    }
  });
}

// ============================================================================
// FILTERS
// ============================================================================

function initFilters() {
  const filterBtns = document.querySelectorAll('[data-filter]');
  const productsContainer = document.getElementById('products-container');
  
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;
      
      // Update active state
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      // Re-render products
      renderProducts(productsContainer, filter, 6);
    });
  });
}

// ============================================================================
// NEWSLETTER
// ============================================================================

function initNewsletter() {
  const form = document.getElementById('newsletter-form');
  
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = form.querySelector('input[name="email"]').value;
    
    try {
      const data = await api('/newsletter/subscribe', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
      
      showToast(data.message || 'Danke für deine Anmeldung!', 'success');
      form.reset();
    } catch (error) {
      showToast(error.message, 'error');
    }
  });
}

// ============================================================================
// EVENT DELEGATION
// ============================================================================

function initEventDelegation() {
  // Product actions
  document.addEventListener('click', (e) => {
    const addCartBtn = e.target.closest('.add-cart-btn');
    const quickViewBtn = e.target.closest('.quick-view-btn');
    const wishlistBtn = e.target.closest('.wishlist-btn');
    
    if (addCartBtn) {
      const productId = parseInt(addCartBtn.dataset.id);
      const product = state.products.find(p => p.id === productId);
      if (product) {
        addToCart(productId, product.variants[0]);
      }
    }
    
    if (quickViewBtn) {
      const productId = parseInt(quickViewBtn.dataset.id);
      openQuickView(productId);
    }
    
    if (wishlistBtn) {
      const productId = parseInt(wishlistBtn.dataset.id);
      toggleWishlist(productId);
    }
  });
  
  // Cart
  document.getElementById('cart-button')?.addEventListener('click', openCart);
  document.getElementById('cart-overlay')?.addEventListener('click', closeCart);
  document.getElementById('close-cart')?.addEventListener('click', closeCart);
  
  // Auth modal
  document.getElementById('login-btn')?.addEventListener('click', () => openAuthModal('login'));
  document.getElementById('auth-modal-close')?.addEventListener('click', closeAuthModal);
  document.getElementById('show-register')?.addEventListener('click', (e) => {
    e.preventDefault();
    openAuthModal('register');
  });
  document.getElementById('show-login')?.addEventListener('click', (e) => {
    e.preventDefault();
    openAuthModal('login');
  });
  
  // Close modals on overlay click
  document.getElementById('auth-modal')?.addEventListener('click', (e) => {
    if (e.target.id === 'auth-modal') closeAuthModal();
  });
  document.getElementById('product-modal')?.addEventListener('click', (e) => {
    if (e.target.id === 'product-modal') closeQuickView();
  });
  
  // Auth forms
  document.getElementById('login-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    await login(email, password);
  });
  
  document.getElementById('register-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    await register(email, password, name);
  });
}

// ============================================================================
// PAGE TRANSITIONS
// ============================================================================

function initPageTransitions() {
  // Check for reduced motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return;
  }
  
  const transition = document.getElementById('page-transition');
  
  document.querySelectorAll('a[href]').forEach(link => {
    // Only internal links
    if (link.hostname !== window.location.hostname) return;
    if (link.getAttribute('href').startsWith('#')) return;
    
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      
      e.preventDefault();
      transition?.classList.add('active');
      
      setTimeout(() => {
        window.location.href = href;
      }, 400);
    });
  });
}

// ============================================================================
// INITIALIZATION
// ============================================================================

async function init() {
  console.log('🌙 LUNARA initializing...');
  
  // Load persisted state
  loadState();
  
  // Initialize UI
  initNavigation();
  initIntroAnimation();
  initHeroParticles();
  initSafeExit();
  initEventDelegation();
  initNewsletter();
  initFilters();
  
  // Load products and render
  await loadProducts();
  const productsContainer = document.getElementById('products-container');
  if (productsContainer) {
    renderProducts(productsContainer, 'All', 6);
  }
  
  // Update UI
  updateCartUI();
  updateAuthUI();
  updateWishlistUI();
  
  // Initialize animations
  initRevealObserver();
  initPageTransitions();
  
  console.log('✨ LUNARA ready!');
}

// Global exports for inline handlers
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateCartQuantity = updateCartQuantity;
window.openCart = openCart;
window.closeCart = closeCart;
window.openQuickView = openQuickView;
window.closeQuickView = closeQuickView;
window.addFromQuickView = addFromQuickView;
window.toggleWishlist = toggleWishlist;
window.showToast = showToast;
window.logout = logout;

// Start the app
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
