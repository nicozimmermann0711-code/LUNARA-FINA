#!/bin/bash
# LUNARA Setup Script
# Run this after downloading the project

echo "🌙 LUNARA Setup"
echo "==============="
echo ""

# Check if wrangler is installed
if ! command -v wrangler &> /dev/null; then
    echo "❌ Wrangler nicht gefunden. Bitte installieren:"
    echo "   npm install -g wrangler"
    exit 1
fi

echo "✅ Wrangler gefunden"
echo ""

# Step 1: Login check
echo "Schritt 1: Cloudflare Login"
echo "---------------------------"
wrangler whoami
echo ""

# Step 2: Get IDs
echo "Schritt 2: Datenbank & KV IDs"
echo "-----------------------------"
echo ""
echo "📦 D1 Datenbanken:"
wrangler d1 list 2>/dev/null | head -10
echo ""
echo "🔑 KV Namespaces:"
wrangler kv:namespace list 2>/dev/null | head -10
echo ""

# Step 3: Instructions
echo "Schritt 3: Konfiguration"
echo "------------------------"
echo ""
echo "1️⃣  Öffne wrangler.jsonc und trage ein:"
echo "    - database_id: Deine D1 Database ID"
echo "    - id (bei kv_namespaces): Deine KV Namespace ID"
echo ""
echo "2️⃣  Secrets setzen:"
echo "    wrangler secret put STRIPE_SECRET_KEY"
echo "    wrangler secret put STRIPE_WEBHOOK_SECRET"
echo "    wrangler secret put JWT_SECRET"
echo ""
echo "3️⃣  Datenbank initialisieren:"
echo "    wrangler d1 execute lunara-db --remote --file=./schema.sql"
echo ""
echo "4️⃣  Stripe Public Key in checkout.html (Zeile 209) eintragen"
echo ""
echo "5️⃣  Deployen:"
echo "    wrangler deploy"
echo ""
echo "🎉 Fertig!"
